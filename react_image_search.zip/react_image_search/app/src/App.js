import Image from './compoenents/image';
import './App.css';

function App() {
  return (
    <Image/>
  );
}

export default App;
